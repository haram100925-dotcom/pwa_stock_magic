/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-7d3ee283'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();
  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "splash.jpg",
    "revision": "f2e0b857d2b297f14b26427c71829036"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "326f981ef8ecd2e4439639268478d6d5"
  }, {
    "url": "pwa-512x512.png",
    "revision": "33ed2fb51be78731f7bb336080d359c2"
  }, {
    "url": "pwa-192x192.png",
    "revision": "b8750f6b0867fa68e195e666d13fdd7c"
  }, {
    "url": "index.html",
    "revision": "5d9f8981839f627500c31927ca510982"
  }, {
    "url": "icon.svg",
    "revision": "18e137ea15ec9deb952f4bb27ac18e79"
  }, {
    "url": "favicon.ico",
    "revision": "1ec882dd3f61c6c34b726b26c21a57c8"
  }, {
    "url": "apple-touch-icon.png",
    "revision": "c773713e18387f683c266b9d2c3cde47"
  }, {
    "url": "assets/workbox-window.prod.es5-Bd17z0YL.js",
    "revision": null
  }, {
    "url": "assets/index-Dg7JVaBd.css",
    "revision": null
  }, {
    "url": "assets/index-DDcLGZKb.js",
    "revision": null
  }, {
    "url": "assets/aistudio/pay_15fdf67c.jpg",
    "revision": null
  }, {
    "url": "assets/aistudio/ic_launcher_520679e6.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_20261108-234849_9a9060cc.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_20261108-232433_cc4f6743.png",
    "revision": null
  }, {
    "url": "assets/aistudio/Screenshot_20261108-224507_c9b1cab1.png",
    "revision": null
  }, {
    "url": "apple-touch-icon.png",
    "revision": "c773713e18387f683c266b9d2c3cde47"
  }, {
    "url": "favicon.ico",
    "revision": "1ec882dd3f61c6c34b726b26c21a57c8"
  }, {
    "url": "pwa-192x192.png",
    "revision": "b8750f6b0867fa68e195e666d13fdd7c"
  }, {
    "url": "pwa-512x512.png",
    "revision": "33ed2fb51be78731f7bb336080d359c2"
  }, {
    "url": "pwa-maskable-512x512.png",
    "revision": "326f981ef8ecd2e4439639268478d6d5"
  }, {
    "url": "splash.jpg",
    "revision": "f2e0b857d2b297f14b26427c71829036"
  }, {
    "url": "manifest.webmanifest",
    "revision": "f37b935f5663102c0b41fbe796601592"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(/^https:\/\/fonts\.googleapis\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "google-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');
  workbox.registerRoute(/^https:\/\/fonts\.gstatic\.com\/.*/i, new workbox.CacheFirst({
    "cacheName": "gstatic-fonts-cache",
    plugins: [new workbox.ExpirationPlugin({
      maxEntries: 10,
      maxAgeSeconds: 31536000
    }), new workbox.CacheableResponsePlugin({
      statuses: [0, 200]
    })]
  }), 'GET');

}));
